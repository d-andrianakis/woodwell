<?php
    include $_SERVER['DOCUMENT_ROOT'].'/opencart/upload/config.php';
    $host         = DB_HOSTNAME; 
    $username     = DB_USERNAME;
    $password     = DB_PASSWORD;
    $dbname       = DB_DATABASE;
    $db_prefix    = DB_PREFIX;
    $dsn          = "mysql:host=". $host .";dbname=". $dbname .";charset=utf8";
    $root = $_SERVER['DOCUMENT_ROOT'];
try {
    $dbconn = new PDO($dsn, $username, $password);
} 
catch (PDOException $e) 
{
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
