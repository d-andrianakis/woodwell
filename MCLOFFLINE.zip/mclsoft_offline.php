<?php
include $_SERVER['DOCUMENT_ROOT'] . '/opencart/upload/system/library/mclsoft/MCLOFFLINE/connection.php';
include $_SERVER['DOCUMENT_ROOT'] . '/opencart/upload/system/library/db.php';

class MCL_offline{
	
	private $store                  = 0;
	private $minimum_quantity       = 1;
	private $subtract_stock         = 1;
	private $requires_shipping      = 1;
	private $date_available         = '0000-00-00';
	private $stock_status           = 7;
	private $status                 = 1;
	private $layout                 = 0;
	private $weight_class_id        = 1;
	private $tax_class_id           = 9;
	private $length_class_id        = 1;
	private $customer_group_id      = 1;
	private $date_start             = '0000-00-00';
	private $date_end               = '0000-00-00';
	private $date_added             = '0000-00-00';
	private $date_modified          = '0000-00-00';
	private $priority               = 100;
	private $option_required        = 1;
	

	
	public function getLanguageId($code) {
	    global $dbconn;
		global $db_prefix;  
		$sql = "SELECT language_id FROM " . $db_prefix . "language WHERE code='" . $code . "'";
		$stmt = $dbconn->prepare($sql);
	    $stmt->execute();
	    $data = $stmt->fetch(PDO::FETCH_ASSOC);        
	    return $data['language_id'];
	}
	
	
	public function getLastId($table_name, $field) {
	    global $dbconn;
		global $db_prefix;  
		$sql = "SELECT MAX(" . $field . ") id FROM " . $db_prefix . $table_name . " WHERE 1=1";
		$stmt = $dbconn->prepare($sql);
	    $stmt->execute();
	    $data = $stmt->fetch(PDO::FETCH_ASSOC);        
	    return $data['id'];
	}
	
	public function addProduct($code, $code1, $quantity, $length_class_id, $tax_class_id, $weight_class_id , $minimum_quantity, $subtract_stock, $stock_status, $id, $extension, $date_available, $manufacturer_id, $requires_shipping, $retailPrice, $status) {
		global $dbconn;
		global $db_prefix;  
		$path = 'catalog/product/';
		$sql = "INSERT INTO " . $db_prefix . "product SET model = '" . $code . "', mpn = '" . $code1 . "', quantity = '" . $quantity . "', length_class_id = '" . $length_class_id . "', tax_class_id = '" . $tax_class_id . "', weight_class_id = '" . $weight_class_id . "', minimum = '" . $minimum_quantity . "', subtract = '" . $subtract_stock . "', stock_status_id = '" . $stock_status . "', image = '" .$path . $id .'_1.' . $extension . "', date_available = NOW(), manufacturer_id = '" . $manufacturer_id . "', shipping = '" . $requires_shipping . "', price = '" . $retailPrice . "', status = '" . $status . "', date_added = NOW(), date_modified = NOW()";
		$stmt = $dbconn->prepare($sql);
	    $stmt->execute();
	    $data = $stmt->fetch(PDO::FETCH_ASSOC); 
		return $this->getLastId('product', 'product_id');
	}
	
	public function addCategory($current_level, $previous_level, $current_description, $level) {
		$data = array();
		
		global $dbconn;
		global $db_prefix;
		
		$cat_id  = "SELECT cdescr.name, cdescr.category_id ";
		$cat_id .= "FROM " . $db_prefix . "category_description as cdescr ";
		$cat_id .= "     inner join " . $db_prefix . "category as cat on cat.category_id = cdescr.category_id ";	
		$cat_id .= "WHERE  cdescr.name = '" . $current_description . "' AND cat.parent_id = " . $previous_level ;
		file_put_contents("sql.log","CAT ID: ".$cat_id."\n",FILE_APPEND);
		$stmt = $dbconn->prepare($cat_id);
	    $stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		/*
		$par_id = "SELECT parent_id FROM " . $db_prefix . "category WHERE category_id = '" . $data["category_id"] . "'";
		$stmt = $dbconn->prepare($par_id);
	    $stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		
		if( $data["parent_id"] == $current_level ){
			return $data["parent_id"];
		}	
				if ($data["name"] == $current_description){
			return "Match!";
		}
		*/
		/*
		if (!empty($data)) {
			return $this->getLastId('category', 'category_id');
		} else { */
		
		/*
		if (!empty($data)) {
			$parent_id = "SELECT parent_id FROM " . $db_prefix . "category WHERE category_id = '" . $cat_id . "'";
			$stmt = $dbconn->prepare($parent_id);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);
			return $data["parent_id"];
		}
		*/
		return $data["name"];
		if ($data["name"] == $current_description){
			return $data["name"];
		} else{
		
			$category  = "INSERT INTO " . $db_prefix . "category SET  image = 'NULL', parent_id = '" . $previous_level . "', top = '0', `column` = '1', sort_order = '" . $current_level . "', status = '1', date_added = NOW(), date_modified = NOW(), skroutz = '1'";
			file_put_contents("sql.log","Category: ".$category."\n",FILE_APPEND);
			$stmt = $dbconn->prepare($category);
			$stmt->execute();	

			$last_id = $this->getLastId('category', 'category_id');
			
			$c2l = "INSERT INTO " . $db_prefix . "category_to_layout SET category_id = '" . $last_id . "', store_id= '0', layout_id = '0'";
			file_put_contents("sql.log","SQL c2l: ".$c2l."\n",FILE_APPEND);
			$stmt = $dbconn->prepare($c2l);
			$stmt->execute(); 

			$c2s = "INSERT INTO " . $db_prefix . "category_to_store SET category_id = '" . $last_id . "', store_id= '0'";
			file_put_contents("sql.log","SQL c2s: ".$c2s."\n",FILE_APPEND);
			$stmt = $dbconn->prepare($c2s);
			$stmt->execute();
			
			
			$cd = "INSERT INTO " . $db_prefix . "category_description SET category_id = '" . $last_id . "', language_id = '1', name = '" . $current_description  . "', description = '" . $current_description ."', meta_title='" . $current_description . "', meta_description='', meta_keyword=''";
			file_put_contents("sql.log","cd: ".$cd."\n",FILE_APPEND);
			$stmt = $dbconn->prepare($cd);
			$stmt->execute();
			
			return $this->getLastId('category', 'category_id');
		}
		
		
	}
	
	public function getParentId($description) {
		
		global $dbconn;
		global $db_prefix;
		
		$cat_id = "SELECT category_id FROM " . $db_prefix . "category_description WHERE name = '" . $description . "'";
		$stmt = $dbconn->prepare($cat_id);
	    $stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$parent_id = "SELECT parent_id FROM " . $db_prefix . "category WHERE category_id = '" . $data["category_id"] . "'";
		$stmt = $dbconn->prepare($parent_id);
	    $stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		return $data["parent_id"];
		
	}
	
	public function getCategoryId($description) {
		global $dbconn;
		global $db_prefix;
		
		$cat_id = "SELECT category_id FROM " . $db_prefix . "category_description WHERE description = '" . $description . "'";
		$stmt = $dbconn->prepare($cat_id);
	    $stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		return $data["category_id"];
		
	}
	
	public function addPath ($current_level, $previous_level, $level) {
		global $dbconn;
		global $db_prefix;
		
		$cp = "INSERT INTO " . $db_prefix . "category_path SET category_id = '" . $current_level . "', path_id = '" . $previous_level  . "', level='" . $level . "'";
		$stmt = $dbconn->prepare($cp);
		$stmt->execute();
	}
	
public function addColor ($color, $color_option_id, $id, $option_value_id, $option_required, $total_quantity, $language_id)
{
	global $dbconn;
	global $db_prefix;  
	$query_color = "SELECT option_id, option_value_id FROM " . DB_PREFIX . "option_value_description WHERE name='" . $color . "'";
	$stmt = $dbconn->prepare($query_color);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);
	
	
	if (!empty($data)) {
		$option_value_id = $query_color->row['option_value_id'];
	}
	else {
		$query_option_value = "INSERT INTO " . $db_prefix . "option_value SET option_id = '" . (int)$color_option_id . "', sort_order = '0'";
		$stmt = $dbconn->prepare($query_option_value);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$option_value_id = $this->getLastId();
		
		$query_option_value_desc = "INSERT INTO " . $db_prefix . "option_value_description SET option_value_id = '" . (int)$option_value_id . "', language_id = '" . (int)$language_id . "', option_id = '" . (int)$color_option_id . "', name = '" . $color . "'";
		$stmt = $dbconn->prepare($query_option_value_desc);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		
		/*
		$query_color = $this->db->query("SELECT option_id, option_value_id FROM " . DB_PREFIX . "option_value_description WHERE option_id = '" . $color_option_id . "' AND name='" . $color_en . "'");
		if ($query_color->num_rows) {
			$option_value_id = $query_color->row['option_value_id'];
		}
		*/
	}
	
	$query_insert_1 = "INSERT INTO " . $db_prefix . "product_option SET product_id = '" . $id . "', option_id = '2', required = '" . $option_required . "'";
	$stmt = $dbconn->prepare($query_insert_1);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);
	
	$product_option_id = $this->getLastId();
	
	$query_insert_2 = "INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$id . "', option_id = '2', option_value_id = '" . (int)$option_value_id . "', quantity = '" . $total_quantity . "', subtract = '1', price = '0', price_prefix = '+', points = '0', points_prefix = '+', weight = '0', weight_prefix = '+'";
	$stmt = $dbconn->prepare($query_insert_2);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);

}


public function addOptions ($combined_array, $id, $option_required, $total_quantity, $language_id)
{
	global $dbconn;
	global $db_prefix;  
	$sql = "INSERT INTO " . $db_prefix . "product_option SET product_id = '" . $id . "', option_id = '11', required = '" . $option_required . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 
	
    $product_option_id = $this->getLastId();
    	
    	
	foreach( $combined_array as $Osize => $Oquantity) {
		
		$query_size = "SELECT option_value_id FROM " . $db_prefix . "option_value_description WHERE name='" . $Osize . "'";
		$stmt = $dbconn->prepare($query_size);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);

	    if (!empty(data)) {
            $option_value_id = $query_size->row['option_value_id'];
        }
        else {
			
			$query_option_value = "INSERT INTO " . $db_prefix . "option_value SET option_id = '11', sort_order = '0'";
			$stmt = $dbconn->prepare($query_option_value);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);
			
            
            $option_value_id = $this->getLastId();
            
			$query_option_value_desc = "INSERT INTO " . $db_prefix . "option_value_description SET option_value_id = '" . (int)$option_value_id . "', language_id = '" . (int)$language_id . "', option_id = '11', name = '" . $Osize . "'";
			$stmt = $dbconn->prepare($query_option_value_desc);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);
			
			
			$query_size = "SELECT option_id, option_value_id FROM " . $db_prefix . "option_value_description WHERE option_id = '11' AND name='" . $Osize . "'";
			$stmt = $dbconn->prepare($query_size);
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_ASSOC);


            if (!empty($data)) {
                $option_value_id = $query_size->row['option_value_id'];
            }
        }
		
		$query_insert = "INSERT INTO " . $db_prefix . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$id . "', option_id = '11', option_value_id = '" . (int)$option_value_id . "', quantity = '" . $Oquantity . "', subtract = '1', price = '0', price_prefix = '+', points = '0', points_prefix = '+', weight = '0', weight_prefix = '+'";
		$stmt = $dbconn->prepare($query_insert);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
    	
	}
}

public function addAttributes ($id, $language_id, $dimensions) {
	
	global $dbconn;
	global $db_prefix;  
	$query_attributes = "SELECT attribute_group_id FROM " . $db_prefix . "attribute_group_description WHERE name = 'Attributes'";
	$stmt = $dbconn->prepare($query_attributes);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!empty($data)) {
        $attribute_group_id = $query_attributes->row['attribute_group_id'];
    } else {
		$query_attribute_group = "INSERT INTO " . $db_prefix . "attribute_group SET sort_order = '0'";
		$stmt = $dbconn->prepare($query_attribute_group);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $attribute_group_id = $this->getLastId();
        
		$query_attribute_group_desc = "INSERT INTO " . $db_prefix . "attribute_group_description SET attribute_group_id = '" . $attribute_group_id . "', name = 'Attributes'";
		$stmt = $dbconn->prepare($query_attribute_group_desc);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$query_attribute_new = "INSERT INTO " . $db_prefix . "attribute SET attribute_group_id = '" . $attribute_group_id . "', sort_order = '0'";
		$stmt = $dbconn->prepare($query_attribute_new);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $attribute_id = $this->getLastId();
        
    }
    
	$query_attributes = "SELECT attribute_id FROM " . $db_prefix . "attribute_description WHERE name='Dimensions'";
	$stmt = $dbconn->prepare($query_attributes);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!empty($data)) {
        $attribute_id = $query_attributes->row['attribute_id'];
    }
     
	$query_attribute_insert = "INSERT INTO " . $db_prefix . "product_attribute SET product_id = '" . $id . "', attribute_id = '" . $attribute_id . "', language_id = '" . $language_id . "', text = '" . $dimensions . "'";
	$stmt = $dbconn->prepare($query_attribute_insert);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC);


}

public function addFilter ($id, $language_id, $filter, $filter_group_id) {
	
	global $dbconn;
	global $db_prefix;  
	$sql = "SELECT filter_id FROM " . DB_PREFIX . "filter_description WHERE name='" . $filter . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 

                    
    if (!empty($data)) {
        $filter_id = $query_season->row['filter_id'];
    } else {
		$sql_1 = "INSERT INTO " . DB_PREFIX . "filter SET filter_group_id = '" . (int)$filter_group_id . "', sort_order = '0'";
		$stmt = $dbconn->prepare($sql_1);
		$stmt->execute();
        
        $filter_id = $this->getLastId('filter', 'filter_group_id');
        
		$sql_2 = "INSERT INTO " . DB_PREFIX . "filter_description SET filter_id = '" . (int)$filter_id . "', language_id = '" . $language_id . "', filter_group_id = '" . (int)$filter_group_id . "', name = '" . $season . "'";
		$stmt = $dbconn->prepare($sql_2);
		$stmt->execute();
		
		$query_filter = "SELECT filter_id FROM " . DB_PREFIX . "filter_description WHERE name = '" . $season . "'";
		$stmt = $dbconn->prepare($query_filter);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC); 
		
        if (!empty($data)) {
            $filter_id = $query_filter->row['filter_id'];
        }
    }
    $query_filter = "INSERT INTO " .DB_PREFIX . "product_filter SET product_id = '" . $id . "',  filter_id = '" . $filter_id . "'";
	$stmt = $dbconn->prepare($query_filter);
	$stmt->execute();
}

public function addSEO ($id, $language_id, $SEO, $store) {
	global $dbconn;
	global $db_prefix;  
	$sql = "INSERT INTO " . DB_PREFIX . "seo_url SET store_id = '" . $store . "', language_id = '" . $language_id . "', query = 'product_id=" . $id . "', keyword = '" . $SEO . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function addDescription ($id, $language_id, $product_name, $description, $tags) {
	global $dbconn;
	global $db_prefix;  
	$sql = "INSERT INTO " . $db_prefix . "product_description SET product_id = '" . $id . "', language_id = '" . $language_id . "', name = '" . $product_name . "', description = '" . $description . "', meta_title = '" . $product_name . "', tag = '" . $tags . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function productToStore($id, $store) {
	global $dbconn;
	global $db_prefix;  
	$sql = "INSERT INTO " . $db_prefix . "product_to_store SET product_id = '" . $id . "', store_id = '" . $store . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function productToLayout($id, $store, $layout) {

	global $dbconn;
	global $db_prefix;  
	$sql = "INSERT INTO " . $db_prefix . "product_to_layout SET product_id = '" . $id . "', store_id = '" . $store . "', layout_id = '" . $layout . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function addAdditionalImages($extension, $last_id, $id, $index) {
	$path = "catalog/product/";
	global $dbconn;
	global $db_prefix; 
	
	$sql = "INSERT INTO " . $db_prefix . "product_image SET product_id = '" . $last_id . "', image = '" .$path . $id .'_' .  $index . '.' . $extension . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
}

public function addProductToCategory($pid, $cat_id) {
	global $dbconn;
	global $db_prefix; 
	
	$sql = "INSERT INTO " . $db_prefix . "product_to_category SET product_id = '" . $pid . "', category_id = '" . $cat_id . "'";
	$stmt = $dbconn->prepare($sql);
	$stmt->execute();
}

}
